# A-GETORTA — Agenda Kegiatan Gereja Toraja Jemaat Tangerang

Paket ini mempertahankan Netlify sebagai hosting dan menambahkan penyimpanan agenda lintas perangkat menggunakan Netlify Functions + Netlify Blobs.

## Isi paket
- `public/index.html` — tampilan agenda, admin, kategori, dan formulir PIC.
- `netlify/functions/agenda.mjs` — API untuk membaca/menyimpan agenda serta memverifikasi dan mengganti PIN admin.
- `netlify.toml` — konfigurasi publish directory, Functions, dan route `/api/agenda`.
- `package.json` — dependensi Netlify Blobs.

## Deployment
1. Buat salinan/backup deployment website lama terlebih dahulu.
2. Unggah isi folder proyek ini ke repository GitHub yang terhubung ke site Netlify, atau deploy folder proyek melalui Netlify CLI. Jangan hanya mengunggah `index.html`; folder `netlify` dan file konfigurasi juga diperlukan.
3. Pada Netlify buka **Site configuration → Environment variables** (atau **Project configuration → Environment variables**). Tambahkan variable `ADMIN_PIN` dengan PIN awal rahasia pilihan Anda. Gunakan minimal 8 karakter. Pilih scope Functions/runtime bila pilihan scope ditampilkan. Jangan menuliskan PIN di source code atau repository.
4. Pastikan build settings memakai base directory root proyek, publish directory `public`, dan build command `npm install` (sudah ditetapkan di `netlify.toml`).
5. Deploy ulang. Setelah deploy sukses, buka domain `a-getorta.com`, masuk ke Mode Admin menggunakan PIN dari `ADMIN_PIN`, lalu uji menambah/mengubah satu kegiatan dan tekan **Terbitkan Perubahan**.
6. Setelah PIN berhasil diganti dari dashboard, PIN baru disimpan sebagai hash di Netlify Blobs dan menjadi PIN admin aktif. Simpan PIN baru dengan aman.

## Cara kerja
- Mode publik membaca agenda terbaru dari `/api/agenda` dan memeriksa pembaruan tiap 45 detik saat halaman terbuka. Jemaat yang membuka ulang halaman langsung membaca data terbaru.
- Tombol **Terbitkan Perubahan** menyimpan agenda di Netlify Blobs, bukan mencoba memanggil API Claude Artifact.
- Nomor WhatsApp pada formulir setiap kegiatan digunakan sebagai nomor PIC untuk tombol Hubungi PIC. Nomor lama pada data awal dimigrasikan otomatis sebagai nomor PIC.
- Filter OIG menampilkan subfilter SMGT, PPGT, PWGT, dan PKBGT.

## Keamanan PIN
Verifikasi PIN dilakukan di Netlify Function, dan PIN pengganti disimpan menggunakan hash scrypt bersalt di Netlify Blobs. Tetap gunakan PIN unik yang panjang. Untuk autentikasi dengan banyak admin, hak akses per orang, atau kebutuhan audit, gunakan layanan autentikasi khusus.

## Catatan
Paket ini harus dijalankan melalui deployment Netlify agar endpoint Functions dan Blobs tersedia. Membuka `public/index.html` langsung dengan double-click (`file://`) tidak mengaktifkan API server.
