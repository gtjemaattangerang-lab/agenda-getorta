import { getStore } from "@netlify/blobs";
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

const store = () => getStore("a-getorta-agenda");
const json = (payload, status = 200) => new Response(JSON.stringify(payload), {
  status,
  headers: {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store, max-age=0",
    "Pragma": "no-cache",
  },
});
const saltForPin = () => randomBytes(16).toString("hex");
const hashPin = (value, salt) => scryptSync(String(value), salt, 64).toString("hex");
const safeHashCompare = (a, b) => {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  return timingSafeEqual(Buffer.from(a), Buffer.from(b));
};

export default async (request) => {
  try {
    const db = store();

    if (request.method === "GET") {
      const published = await db.get("published", { type: "json" });
      return json(published || { events: null, updatedAt: null });
    }

    if (request.method !== "POST") {
      return json({ message: "Metode tidak didukung." }, 405);
    }

    let body;
    try { body = await request.json(); }
    catch { return json({ message: "Format permintaan tidak valid." }, 400); }

    const action = body?.action;
    const candidatePin = request.headers.get("x-admin-pin") || "";
    const savedAuth = await db.get("auth", { type: "json" });
    const configuredInitialPin = process.env.ADMIN_PIN || "";
    const authorized = savedAuth?.pinHash && savedAuth?.salt
      ? safeHashCompare(hashPin(candidatePin, savedAuth.salt), savedAuth.pinHash)
      : Boolean(configuredInitialPin && candidatePin === configuredInitialPin);

    if (action === "verify") {
      if (!configuredInitialPin && !savedAuth?.pinHash) {
        return json({ message: "ADMIN_PIN belum diatur pada Environment Variables Netlify." }, 503);
      }
      return authorized ? json({ ok: true }) : json({ message: "PIN admin tidak sesuai." }, 401);
    }

    if (!authorized) {
      if (!configuredInitialPin && !savedAuth?.pinHash) {
        return json({ message: "ADMIN_PIN belum diatur pada Environment Variables Netlify." }, 503);
      }
      return json({ message: "PIN admin tidak sesuai atau sesi tidak valid." }, 401);
    }

    if (action === "publish") {
      if (!Array.isArray(body.events) || body.events.length > 1500) {
        return json({ message: "Data agenda tidak valid atau terlalu banyak." }, 400);
      }
      const payload = { events: body.events, updatedAt: new Date().toISOString() };
      await db.setJSON("published", payload);
      return json({ ok: true, updatedAt: payload.updatedAt });
    }

    if (action === "changePin") {
      const newPin = String(body.newPin || "");
      if (newPin.length < 8 || newPin.length > 128) {
        return json({ message: "PIN baru harus terdiri dari 8–128 karakter." }, 400);
      }
      const salt = saltForPin();
      await db.setJSON("auth", { salt, pinHash: hashPin(newPin, salt), changedAt: new Date().toISOString() });
      return json({ ok: true });
    }

    return json({ message: "Aksi tidak dikenal." }, 400);
  } catch (error) {
    console.error("Agenda function error:", error);
    return json({ message: "Terjadi kendala pada penyimpanan agenda. Silakan coba kembali." }, 500);
  }
};
